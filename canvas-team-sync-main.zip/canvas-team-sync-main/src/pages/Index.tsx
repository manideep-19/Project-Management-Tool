import React, { useState, useMemo } from 'react';
import { LogOut, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Column from '@/components/Column';
import AddTaskModal from '@/components/AddTaskModal';
import LoginModal from '@/components/auth/LoginModal';
import { useAuth } from '@/hooks/useAuth';
import { useTasks } from '@/hooks/useTasks';

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  status: string;
  assignee?: string;
  dueDate?: string;
}

export interface ColumnData {
  id: string;
  title: string;
  tasks: Task[];
}

const Index = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const { tasks, loading: tasksLoading, addTask, updateTask, deleteTask, moveTask } = useTasks(user?.id);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [selectedColumn, setSelectedColumn] = useState<string>('todo');

  const columns = useMemo(() => {
    const todoTasks = tasks.filter(task => task.status === 'todo');
    const inProgressTasks = tasks.filter(task => task.status === 'inprogress');
    const doneTasks = tasks.filter(task => task.status === 'done');

    return [
      { id: 'todo', title: 'To Do', tasks: todoTasks },
      { id: 'inprogress', title: 'In Progress', tasks: inProgressTasks },
      { id: 'done', title: 'Done', tasks: doneTasks }
    ];
  }, [tasks]);

  const handleAddTask = async (task: Omit<Task, 'id'>) => {
    await addTask(task, selectedColumn);
  };

  const handleUpdateTask = async (taskId: string, updatedTask: Partial<Task>) => {
    await updateTask(taskId, updatedTask);
  };

  const handleDeleteTask = async (taskId: string) => {
    await deleteTask(taskId);
  };

  const handleMoveTask = async (taskId: string, fromColumnId: string, toColumnId: string) => {
    if (fromColumnId === toColumnId) return;
    await moveTask(taskId, toColumnId);
  };

  const openAddModal = (columnId: string) => {
    setSelectedColumn(columnId);
    setIsAddModalOpen(true);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center max-w-2xl mx-auto">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Project Board</h1>
            <p className="text-gray-600 text-lg mb-8">
              Organize and track your team's work efficiently with AI-powered features
            </p>
            <Button 
              onClick={() => setIsLoginModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
            >
              Get Started
            </Button>
          </div>
        </div>
        
        <LoginModal 
          isOpen={isLoginModalOpen}
          onClose={() => setIsLoginModalOpen(false)}
          onSuccess={() => {}}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Project Board</h1>
            <p className="text-gray-600 text-lg">Organize and track your team's work efficiently</p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-gray-600">
              <User className="h-4 w-4" />
              <span>{user.email}</span>
            </div>
            <Button
              onClick={signOut}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <LogOut className="h-4 w-4" />
              Sign Out
            </Button>
          </div>
        </div>

        {tasksLoading ? (
          <div className="text-center py-12">
            <div className="text-lg text-gray-600">Loading tasks...</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {columns.map(column => (
              <Column
                key={column.id}
                column={column}
                onAddTask={() => openAddModal(column.id)}
                onUpdateTask={handleUpdateTask}
                onDeleteTask={handleDeleteTask}
                onMoveTask={handleMoveTask}
              />
            ))}
          </div>
        )}

        <AddTaskModal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onAdd={handleAddTask}
        />
      </div>
    </div>
  );
};

export default Index;
