
import React from 'react';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import TaskCard from './TaskCard';
import { ColumnData, Task } from '@/pages/Index';

interface ColumnProps {
  column: ColumnData;
  onAddTask: () => void;
  onUpdateTask: (taskId: string, updatedTask: Partial<Task>) => void;
  onDeleteTask: (taskId: string) => void;
  onMoveTask: (taskId: string, fromColumnId: string, toColumnId: string) => void;
}

const Column: React.FC<ColumnProps> = ({
  column,
  onAddTask,
  onUpdateTask,
  onDeleteTask,
  onMoveTask
}) => {
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const dragData = e.dataTransfer.getData('text/plain');
    const { taskId, fromColumnId } = JSON.parse(dragData);
    onMoveTask(taskId, fromColumnId, column.id);
  };

  return (
    <div 
      className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 h-fit"
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <h2 className="text-xl font-semibold text-gray-900">{column.title}</h2>
          <span className="bg-gray-100 text-gray-600 text-sm font-medium px-2.5 py-1 rounded-full">
            {column.tasks.length}
          </span>
        </div>
        <Button
          onClick={onAddTask}
          size="sm"
          className="bg-blue-600 hover:bg-blue-700 text-white shadow-sm"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <div className="space-y-4">
        {column.tasks.map(task => (
          <TaskCard
            key={task.id}
            task={task}
            columnId={column.id}
            onUpdate={onUpdateTask}
            onDelete={onDeleteTask}
          />
        ))}
        
        {column.tasks.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <div className="text-lg mb-2">No tasks yet</div>
            <div className="text-sm">Add a task to get started</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Column;
